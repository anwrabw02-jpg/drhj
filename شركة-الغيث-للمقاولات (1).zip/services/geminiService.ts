import { GoogleGenAI, Chat } from "@google/genai";

const apiKey = process.env.API_KEY || '';

// Initialize the Gemini client
const ai = new GoogleGenAI({ apiKey });

// System instruction for the construction company assistant
const SYSTEM_INSTRUCTION = `
أنت المساعد الذكي لشركة "الغيث للمقاولات". دورك هو مساعدة الزوار والعملاء المحتملين في الرد على استفساراتهم بخصوص البناء، المقاولات، التصميم، والترميم.
تحدث باللغة العربية بأسلوب مهني، لبق، ومرحب.
معلومات عن الشركة:
- الاسم: شركة الغيث للمقاولات.
- الخدمات: البناء السكني والتجاري، التشطيبات، الترميم، التصميم الداخلي والخارجي، الاستشارات الهندسية، إدارة المشاريع.
- القيم: الجودة، الالتزام بالوقت، الشفافية، السلامة المهنية.
- الموقع: الرياض، المملكة العربية السعودية.

إذا سألك أحد عن الأسعار، أخبره أن الأسعار تعتمد على تفاصيل المشروع والمساحة والمواصفات، واقترح عليه استخدام نموذج "تواصل معنا" أو زيارة المكتب للحصول على عرض سعر دقيق.
لا تعطي أسعاراً محددة وجازمة، بل أعطِ تقديرات عامة جداً إذا اضطررت، مع التأكيد أنها تقريبية.
`;

let chatSession: Chat | null = null;

export const getChatSession = (): Chat => {
  if (!chatSession) {
    chatSession = ai.chats.create({
      model: 'gemini-2.5-flash',
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
      },
    });
  }
  return chatSession;
};

export const sendMessageToGemini = async (message: string): Promise<AsyncIterable<string>> => {
  if (!apiKey) {
    throw new Error("API Key is missing.");
  }

  const chat = getChatSession();
  
  try {
    const result = await chat.sendMessageStream({ message });
    
    // Create a generator to yield text chunks
    async function* streamGenerator() {
      for await (const chunk of result) {
        if (chunk.text) {
          yield chunk.text;
        }
      }
    }

    return streamGenerator();
  } catch (error) {
    console.error("Error sending message to Gemini:", error);
    throw error;
  }
};