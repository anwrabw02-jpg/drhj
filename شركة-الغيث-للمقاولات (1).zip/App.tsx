import React, { useState } from 'react';
import { Icons } from './components/Icons';
import { ChatWidget } from './components/ChatWidget';
import { SectionId, ServiceItem, ProjectItem } from './types';

// Data
const services: ServiceItem[] = [
  { id: '1', title: 'البناء والتشييد', description: 'تنفيذ المشاريع السكنية والتجارية بأعلى معايير الجودة العالمية.', iconName: 'Building' },
  { id: '2', title: 'التصميم الداخلي والديكور', description: 'تحويل المساحات الداخلية إلى تحف فنية تجمع بين الجمال والوظيفة.', iconName: 'Design' },
  { id: '3', title: 'الترميم والصيانة', description: 'إعادة تأهيل المباني القديمة وصيانتها لتعود كالجديدة.', iconName: 'Construction' },
  { id: '4', title: 'الاستشارات الهندسية', description: 'دراسات جدوى وتخطيط هندسي دقيق لضمان نجاح مشروعك.', iconName: 'Planning' },
  { id: '5', title: 'إدارة المشاريع', description: 'إشراف كامل على جميع مراحل التنفيذ لضمان الالتزام بالوقت والميزانية.', iconName: 'Safety' },
  { id: '6', title: 'الدعم اللوجستي', description: 'توفير المعدات والمواد اللازمة للمواقع بسرعة وكفاءة.', iconName: 'Logistics' },
];

const projects: ProjectItem[] = [
  { id: '1', title: 'فيلا الياسمين', category: 'سكني', imageUrl: 'https://picsum.photos/800/600?random=1' },
  { id: '2', title: 'مجمع الأعمال', category: 'تجاري', imageUrl: 'https://picsum.photos/800/600?random=2' },
  { id: '3', title: 'ترميم قصر التراث', category: 'ترميم', imageUrl: 'https://picsum.photos/800/600?random=3' },
  { id: '4', title: 'برج الأفق', category: 'تجاري', imageUrl: 'https://picsum.photos/800/600?random=4' },
  { id: '5', title: 'شاليهات النخيل', category: 'سياحي', imageUrl: 'https://picsum.photos/800/600?random=5' },
  { id: '6', title: 'تصميم داخلي لمكتب', category: 'ديكور', imageUrl: 'https://picsum.photos/800/600?random=6' },
];

const App: React.FC = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const scrollToSection = (id: SectionId) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setMobileMenuOpen(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col font-sans">
      {/* Navbar */}
      <nav className="bg-white shadow-md fixed w-full z-40 transition-all duration-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-20">
            <div className="flex items-center">
              <div className="flex-shrink-0 flex items-center gap-2 cursor-pointer" onClick={() => scrollToSection(SectionId.HOME)}>
                <Icons.Building className="h-8 w-8 text-primary-600" />
                <span className="font-bold text-2xl text-primary-900 tracking-wide">الغيث للمقاولات</span>
              </div>
            </div>
            
            {/* Desktop Menu */}
            <div className="hidden md:flex items-center space-x-8 space-x-reverse">
              <button onClick={() => scrollToSection(SectionId.HOME)} className="text-gray-600 hover:text-primary-600 px-3 py-2 rounded-md text-sm font-medium transition-colors">الرئيسية</button>
              <button onClick={() => scrollToSection(SectionId.ABOUT)} className="text-gray-600 hover:text-primary-600 px-3 py-2 rounded-md text-sm font-medium transition-colors">من نحن</button>
              <button onClick={() => scrollToSection(SectionId.SERVICES)} className="text-gray-600 hover:text-primary-600 px-3 py-2 rounded-md text-sm font-medium transition-colors">خدماتنا</button>
              <button onClick={() => scrollToSection(SectionId.PROJECTS)} className="text-gray-600 hover:text-primary-600 px-3 py-2 rounded-md text-sm font-medium transition-colors">أعمالنا</button>
              <button 
                onClick={() => scrollToSection(SectionId.CONTACT)} 
                className="bg-primary-600 text-white px-5 py-2.5 rounded-full text-sm font-medium hover:bg-primary-700 transition-colors shadow-lg hover:shadow-xl"
              >
                تواصل معنا
              </button>
            </div>

            {/* Mobile menu button */}
            <div className="flex items-center md:hidden">
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-primary-500"
              >
                {mobileMenuOpen ? <Icons.Close className="block h-6 w-6" /> : <Icons.Menu className="block h-6 w-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-white border-b border-gray-100">
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 text-right">
              <button onClick={() => scrollToSection(SectionId.HOME)} className="text-gray-600 hover:text-primary-600 block px-3 py-2 rounded-md text-base font-medium w-full text-right">الرئيسية</button>
              <button onClick={() => scrollToSection(SectionId.ABOUT)} className="text-gray-600 hover:text-primary-600 block px-3 py-2 rounded-md text-base font-medium w-full text-right">من نحن</button>
              <button onClick={() => scrollToSection(SectionId.SERVICES)} className="text-gray-600 hover:text-primary-600 block px-3 py-2 rounded-md text-base font-medium w-full text-right">خدماتنا</button>
              <button onClick={() => scrollToSection(SectionId.PROJECTS)} className="text-gray-600 hover:text-primary-600 block px-3 py-2 rounded-md text-base font-medium w-full text-right">أعمالنا</button>
              <button onClick={() => scrollToSection(SectionId.CONTACT)} className="text-primary-600 font-bold block px-3 py-2 rounded-md text-base w-full text-right">تواصل معنا</button>
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section id={SectionId.HOME} className="relative pt-20 flex items-center min-h-[90vh] bg-primary-900 overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1541888946425-d81bb19240f5?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80" 
            alt="Construction background" 
            className="w-full h-full object-cover opacity-20"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-primary-900 via-primary-900/80 to-transparent"></div>
        </div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center">
          <div className="w-full md:w-1/2 text-center md:text-right pt-10 md:pt-0">
            <h1 className="text-4xl md:text-6xl font-extrabold text-white leading-tight mb-6">
              نحول رؤيتكم <br />
              <span className="text-secondary-500">إلى واقع ملموس</span>
            </h1>
            <p className="text-lg md:text-xl text-gray-300 mb-8 max-w-2xl mx-auto md:mx-0 leading-relaxed">
              شركة الغيث للمقاولات تقدم لكم أفضل حلول البناء والتشييد بمعايير عالمية، نجمع بين الخبرة العريقة والتكنولوجيا الحديثة لنبني مستقبلاً أفضل.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start">
              <button onClick={() => scrollToSection(SectionId.CONTACT)} className="px-8 py-4 bg-secondary-500 hover:bg-secondary-600 text-white rounded-full font-bold text-lg transition-transform hover:scale-105 shadow-lg flex items-center justify-center gap-2">
                اطلب عرض سعر <Icons.Arrow className="w-5 h-5 rotate-180" />
              </button>
              <button onClick={() => scrollToSection(SectionId.PROJECTS)} className="px-8 py-4 bg-transparent border-2 border-white text-white hover:bg-white hover:text-primary-900 rounded-full font-bold text-lg transition-colors flex items-center justify-center">
                تصفح أعمالنا
              </button>
            </div>
          </div>
          
          <div className="hidden md:block w-1/2 relative mt-12 md:mt-0">
              {/* Optional: A floating image or 3D element could go here, or leave as negative space for the background */}
              <div className="relative">
                 <img src="https://images.unsplash.com/photo-1504307651254-35680f356dfd?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" 
                      className="rounded-lg shadow-2xl border-4 border-white/10 transform rotate-3 hover:rotate-0 transition-transform duration-500 w-4/5 mx-auto"
                      alt="Modern building"
                 />
                 <div className="absolute -bottom-10 -right-10 bg-white p-6 rounded-lg shadow-xl max-w-xs">
                    <div className="flex items-center gap-4 mb-2">
                        <div className="bg-green-100 p-2 rounded-full text-green-600">
                            <Icons.Check size={24} />
                        </div>
                        <div>
                            <p className="font-bold text-gray-900">15+ سنة</p>
                            <p className="text-sm text-gray-500">من الخبرة والتميز</p>
                        </div>
                    </div>
                 </div>
              </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id={SectionId.ABOUT} className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row gap-16 items-center">
            <div className="w-full md:w-1/2">
              <img 
                src="https://images.unsplash.com/photo-1581094794329-c8112a89af12?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80" 
                alt="Engineers discussing" 
                className="rounded-2xl shadow-xl w-full object-cover h-[500px]"
              />
            </div>
            <div className="w-full md:w-1/2 text-right">
              <span className="text-secondary-600 font-bold text-sm tracking-wider uppercase mb-2 block">من نحن</span>
              <h2 className="text-3xl md:text-4xl font-bold text-primary-900 mb-6">شريكك الموثوق في عالم البناء</h2>
              <p className="text-gray-600 leading-relaxed mb-6">
                تأسست شركة الغيث للمقاولات برؤية طموحة تهدف إلى إحداث نقلة نوعية في قطاع المقاولات. نفخر بفريقنا المكون من نخبة المهندسين والفنيين الذين يعملون بشغف لتحقيق أعلى مستويات الجودة.
              </p>
              <p className="text-gray-600 leading-relaxed mb-8">
                نحن نؤمن بأن البناء ليس مجرد خرسانة وحديد، بل هو فن صناعة البيئات التي يعيش ويعمل فيها الإنسان. لذلك، نلتزم بأدق التفاصيل ونستخدم أفضل المواد لضمان استدامة وجمال مشاريعنا.
              </p>
              
              <div className="grid grid-cols-2 gap-6">
                <div className="border-r-4 border-secondary-500 pr-4">
                  <h4 className="text-2xl font-bold text-primary-800 mb-1">150+</h4>
                  <p className="text-gray-500 text-sm">مشروع مكتمل</p>
                </div>
                <div className="border-r-4 border-secondary-500 pr-4">
                  <h4 className="text-2xl font-bold text-primary-800 mb-1">50+</h4>
                  <p className="text-gray-500 text-sm">خبير ومحترف</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id={SectionId.SERVICES} className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <span className="text-secondary-600 font-bold text-sm tracking-wider uppercase">خدماتنا</span>
            <h2 className="text-3xl md:text-4xl font-bold text-primary-900 mt-2">حلول متكاملة لاحتياجاتك</h2>
            <div className="w-20 h-1 bg-secondary-500 mx-auto mt-4 rounded-full"></div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service) => {
              const IconComponent = (Icons as any)[service.iconName] || Icons.Building;
              return (
                <div key={service.id} className="bg-white p-8 rounded-2xl shadow-sm hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 border border-gray-100 group">
                  <div className="w-14 h-14 bg-primary-50 rounded-xl flex items-center justify-center text-primary-600 mb-6 group-hover:bg-primary-600 group-hover:text-white transition-colors">
                    <IconComponent size={32} />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-3">{service.title}</h3>
                  <p className="text-gray-500 leading-relaxed text-sm">
                    {service.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section id={SectionId.PROJECTS} className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-end mb-12">
            <div className="text-right">
              <span className="text-secondary-600 font-bold text-sm tracking-wider uppercase">معرض الأعمال</span>
              <h2 className="text-3xl md:text-4xl font-bold text-primary-900 mt-2">أحدث مشاريعنا المتميزة</h2>
            </div>
            <button className="hidden md:flex items-center gap-2 text-primary-600 font-bold hover:text-primary-800 transition-colors mt-4 md:mt-0">
              مشاهدة جميع المشاريع <Icons.Arrow className="w-5 h-5 rotate-180" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {projects.map((project) => (
              <div key={project.id} className="group relative overflow-hidden rounded-2xl cursor-pointer">
                <div className="aspect-w-4 aspect-h-3">
                  <img 
                    src={project.imageUrl} 
                    alt={project.title} 
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-6">
                  <span className="text-secondary-400 text-sm font-medium mb-1">{project.category}</span>
                  <h3 className="text-white text-xl font-bold">{project.title}</h3>
                </div>
              </div>
            ))}
          </div>
          
          <div className="mt-8 text-center md:hidden">
             <button className="inline-flex items-center gap-2 text-primary-600 font-bold hover:text-primary-800 transition-colors">
              مشاهدة جميع المشاريع <Icons.Arrow className="w-5 h-5 rotate-180" />
            </button>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id={SectionId.CONTACT} className="py-20 bg-primary-900 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div className="text-white">
              <span className="text-secondary-400 font-bold text-sm tracking-wider uppercase">تواصل معنا</span>
              <h2 className="text-3xl md:text-4xl font-bold mt-2 mb-6">هل لديك مشروع في ذهنك؟ <br/> لنبدأ العمل عليه اليوم.</h2>
              <p className="text-primary-100 mb-10 text-lg">
                فريقنا جاهز للرد على جميع استفساراتكم وتقديم الاستشارات اللازمة لمشاريعكم.
              </p>
              
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="bg-white/10 p-3 rounded-lg text-secondary-400">
                    <Icons.Phone size={24} />
                  </div>
                  <div>
                    <h4 className="text-lg font-bold">اتصل بنا</h4>
                    <p className="text-primary-200" dir="ltr">+966 50 123 4567</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-4">
                  <div className="bg-white/10 p-3 rounded-lg text-secondary-400">
                    <Icons.Mail size={24} />
                  </div>
                  <div>
                    <h4 className="text-lg font-bold">البريد الإلكتروني</h4>
                    <p className="text-primary-200" dir="ltr">info@alghaith-co.sa</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-4">
                  <div className="bg-white/10 p-3 rounded-lg text-secondary-400">
                    <Icons.MapPin size={24} />
                  </div>
                  <div>
                    <h4 className="text-lg font-bold">مقرنا الرئيسي</h4>
                    <p className="text-primary-200">الرياض، حي العليا، شارع التخصصي</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-3xl p-8 shadow-2xl">
              <form className="space-y-6" onSubmit={(e) => {
                e.preventDefault();
                alert('شكراً لتواصلك معنا! تم استلام طلبك بنجاح.');
              }}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">الاسم الكامل</label>
                    <input type="text" required className="w-full px-4 py-3 rounded-xl bg-gray-50 border border-gray-200 focus:ring-2 focus:ring-primary-500 focus:border-transparent outline-none transition-all" placeholder="محمد أحمد" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">رقم الهاتف</label>
                    <input type="tel" required className="w-full px-4 py-3 rounded-xl bg-gray-50 border border-gray-200 focus:ring-2 focus:ring-primary-500 focus:border-transparent outline-none transition-all" placeholder="050xxxxxxx" />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">البريد الإلكتروني</label>
                  <input type="email" required className="w-full px-4 py-3 rounded-xl bg-gray-50 border border-gray-200 focus:ring-2 focus:ring-primary-500 focus:border-transparent outline-none transition-all" placeholder="example@email.com" />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">نوع الخدمة</label>
                  <select className="w-full px-4 py-3 rounded-xl bg-gray-50 border border-gray-200 focus:ring-2 focus:ring-primary-500 focus:border-transparent outline-none transition-all">
                    <option>بناء وتشيد</option>
                    <option>تصميم داخلي</option>
                    <option>ترميم وصيانة</option>
                    <option>استشارة هندسية</option>
                    <option>أخرى</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">رسالتك</label>
                  <textarea rows={4} required className="w-full px-4 py-3 rounded-xl bg-gray-50 border border-gray-200 focus:ring-2 focus:ring-primary-500 focus:border-transparent outline-none transition-all" placeholder="أخبرنا المزيد عن مشروعك..."></textarea>
                </div>
                
                <button type="submit" className="w-full bg-primary-600 hover:bg-primary-700 text-white font-bold py-4 rounded-xl shadow-lg transition-all hover:shadow-xl transform hover:-translate-y-1">
                  إرسال الطلب
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-400 py-12 border-t border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
            <div>
               <div className="flex items-center gap-2 mb-4">
                <Icons.Building className="h-6 w-6 text-white" />
                <span className="font-bold text-xl text-white">الغيث للمقاولات</span>
              </div>
              <p className="text-sm leading-relaxed mb-4">
                نسعى دائماً لتقديم أفضل الخدمات لعملائنا الكرام من خلال فريق عمل محترف ومتخصص.
              </p>
            </div>
            
            <div>
              <h4 className="text-white font-bold mb-4">روابط سريعة</h4>
              <ul className="space-y-2 text-sm">
                <li><button onClick={() => scrollToSection(SectionId.HOME)} className="hover:text-white transition-colors">الرئيسية</button></li>
                <li><button onClick={() => scrollToSection(SectionId.ABOUT)} className="hover:text-white transition-colors">من نحن</button></li>
                <li><button onClick={() => scrollToSection(SectionId.SERVICES)} className="hover:text-white transition-colors">الخدمات</button></li>
                <li><button onClick={() => scrollToSection(SectionId.PROJECTS)} className="hover:text-white transition-colors">المشاريع</button></li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-white font-bold mb-4">الخدمات</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="hover:text-white transition-colors">المقاولات العامة</a></li>
                <li><a href="#" className="hover:text-white transition-colors">التصميم والديكور</a></li>
                <li><a href="#" className="hover:text-white transition-colors">الترميم</a></li>
                <li><a href="#" className="hover:text-white transition-colors">إدارة المشاريع</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-white font-bold mb-4">ساعات العمل</h4>
              <ul className="space-y-2 text-sm">
                <li className="flex justify-between"><span>الأحد - الخميس</span> <span>8:00 ص - 6:00 م</span></li>
                <li className="flex justify-between"><span>الجمعة</span> <span>مغلق</span></li>
                <li className="flex justify-between"><span>السبت</span> <span>9:00 ص - 2:00 م</span></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-800 pt-8 text-center text-sm">
            <p>&copy; {new Date().getFullYear()} شركة الغيث للمقاولات. جميع الحقوق محفوظة.</p>
          </div>
        </div>
      </footer>

      {/* AI Chat Assistant */}
      <ChatWidget />
    </div>
  );
};

export default App;