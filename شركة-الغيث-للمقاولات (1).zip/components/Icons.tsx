import React from 'react';
import { 
  Building2, 
  Hammer, 
  PaintBucket, 
  HardHat, 
  Ruler, 
  Truck, 
  Phone, 
  MapPin, 
  Mail, 
  Menu, 
  X, 
  Send,
  MessageSquare,
  Bot,
  User,
  CheckCircle2,
  ArrowRight
} from 'lucide-react';

export const Icons = {
  Building: Building2,
  Construction: Hammer,
  Design: PaintBucket,
  Safety: HardHat,
  Planning: Ruler,
  Logistics: Truck,
  Phone,
  MapPin,
  Mail,
  Menu,
  Close: X,
  Send,
  Chat: MessageSquare,
  Bot,
  User,
  Check: CheckCircle2,
  Arrow: ArrowRight
};